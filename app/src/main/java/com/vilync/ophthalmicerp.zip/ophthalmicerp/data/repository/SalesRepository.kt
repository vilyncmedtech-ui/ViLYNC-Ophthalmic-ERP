package com.vilync.ophthalmicerp.data.repository

import androidx.room.withTransaction
import com.vilync.ophthalmicerp.data.dao.SalesDao
import com.vilync.ophthalmicerp.data.database.AppDatabase
import com.vilync.ophthalmicerp.data.entity.SaleEntity
import com.vilync.ophthalmicerp.data.entity.SaleItemEntity
import com.vilync.ophthalmicerp.data.entity.SaleLensEntity
import com.vilync.ophthalmicerp.data.entity.StockMovementEntity
import kotlinx.coroutines.flow.Flow


class SalesRepository(

    private val salesDao: SalesDao,

    private val database: AppDatabase

) {


    // =========================================================
    // DUPLICATE INVOICE CHECK - NEW SALE
    // =========================================================

    suspend fun saleInvoiceExists(
        customerId: Long,
        invoiceNumber: String
    ): Boolean {

        val normalizedInvoiceNumber =
            invoiceNumber.trim()

        if (
            customerId <= 0L ||
            normalizedInvoiceNumber.isBlank()
        ) {
            return false
        }

        return salesDao.saleInvoiceExists(
            customerId = customerId,
            invoiceNumber = normalizedInvoiceNumber
        )
    }


    // =========================================================
    // DUPLICATE INVOICE CHECK - EDIT SALE
    // =========================================================

    suspend fun saleInvoiceExistsExcludingSale(
        customerId: Long,
        invoiceNumber: String,
        excludeSaleId: Long
    ): Boolean {

        val normalizedInvoiceNumber =
            invoiceNumber.trim()

        if (
            customerId <= 0L ||
            normalizedInvoiceNumber.isBlank() ||
            excludeSaleId <= 0L
        ) {
            return false
        }

        return salesDao
            .saleInvoiceExistsExcludingSale(
                customerId = customerId,
                invoiceNumber = normalizedInvoiceNumber,
                excludeSaleId = excludeSaleId
            )
    }


    // =========================================================
    // SAVE COMPLETE NEW SALE
    // =========================================================
    //
    // ViLYNC SAFE SALES INVENTORY TRANSACTION
    //
    // 1. Validate Sale header.
    // 2. Validate every selected physical Inventory Unit.
    // 3. Every selected serial must still be IN_STOCK.
    // 4. Product / Power must match the Sale Item.
    // 5. Same physical Inventory Unit cannot appear twice.
    // 6. Save Sale + Items + Lenses.
    // 7. Change selected Inventory Units to SOLD.
    // 8. Create permanent SOLD Stock Movement entries.
    //
    // Entire operation runs inside one Room transaction.
    //
    // If any validation / insert / stock update fails,
    // the complete transaction is rolled back.
    // =========================================================

    suspend fun saveCompleteSale(
        sale: SaleEntity,
        itemsWithLenses:
        List<Pair<SaleItemEntity, List<SaleLensEntity>>>
    ): Long {

        // =====================================================
        // BASIC DOCUMENT VALIDATION
        // =====================================================

        require(
            sale.id == 0L
        ) {
            "New Sale must not already have a database ID."
        }

        require(
            sale.customerId > 0L
        ) {
            "Customer / Hospital is required."
        }

        require(
            sale.customerName.trim().isNotBlank()
        ) {
            "Customer / Hospital name is required."
        }

        require(
            sale.invoiceNumber.trim().isNotBlank()
        ) {
            "Sales Invoice Number is required."
        }

        require(
            sale.invoiceDate.trim().isNotBlank()
        ) {
            "Sales Invoice Date is required."
        }

        require(
            sale.financialYearStart > 0
        ) {
            "Valid Financial Year is required."
        }

        require(
            itemsWithLenses.isNotEmpty()
        ) {
            "At least one Sales item is required."
        }


        return database.withTransaction {

            val inventoryDao =
                database.inventoryDao()

            val stockMovementDao =
                database.stockMovementDao()


            // =================================================
            // STEP 1
            // FINAL DUPLICATE INVOICE CHECK
            // =================================================
            //
            // UI/ViewModel may already perform a live duplicate
            // check, but repository validates again immediately
            // before persistence.
            // =================================================

            val duplicateInvoiceExists =
                salesDao.saleInvoiceExists(
                    customerId =
                        sale.customerId,

                    invoiceNumber =
                        sale.invoiceNumber.trim()
                )


            require(
                !duplicateInvoiceExists
            ) {
                "Sales Invoice Number ${sale.invoiceNumber.trim()} already exists for ${sale.customerName.trim()}."
            }


            // =================================================
            // STEP 2
            // VALIDATE ITEM STRUCTURE
            // =================================================

            itemsWithLenses.forEachIndexed {
                    itemIndex,
                    itemWithLenses ->

                val item =
                    itemWithLenses.first

                require(
                    item.productId > 0L
                ) {
                    "Valid Product is required for Sales item ${itemIndex + 1}."
                }

                require(
                    item.productName.trim().isNotBlank()
                ) {
                    "Product name is required for Sales item ${itemIndex + 1}."
                }

                require(
                    item.quantity > 0
                ) {
                    "Quantity must be greater than zero for ${item.productName.trim()}."
                }

                require(
                    item.rate >= 0.0
                ) {
                    "Rate cannot be negative for ${item.productName.trim()}."
                }

                require(
                    item.discountPercent >= 0.0
                ) {
                    "Discount cannot be negative for ${item.productName.trim()}."
                }

                require(
                    item.gstPercent >= 0.0
                ) {
                    "GST cannot be negative for ${item.productName.trim()}."
                }
            }


            // =================================================
            // STEP 3
            // COLLECT + VALIDATE SELECTED INVENTORY UNIT IDS
            // =================================================

            val selectedInventoryUnitIds =
                itemsWithLenses
                    .flatMap {
                        it.second
                    }
                    .map {
                        it.inventoryUnitId
                    }


            require(
                selectedInventoryUnitIds.none {
                    it <= 0L
                }
            ) {
                "Every selected serial must have a valid Inventory Unit."
            }


            require(
                selectedInventoryUnitIds.size ==
                        selectedInventoryUnitIds
                            .distinct()
                            .size
            ) {
                "The same physical Serial Number cannot be selected more than once in one Sales Invoice."
            }


            // =================================================
            // STEP 4
            // VALIDATE EVERY PHYSICAL SERIAL AGAINST LIVE STOCK
            // =================================================
            //
            // Never trust UI state alone.
            //
            // InventoryUnit is the authoritative physical stock
            // identity.
            // =================================================

            itemsWithLenses.forEach { itemWithLenses ->

                val saleItem =
                    itemWithLenses.first

                val saleLenses =
                    itemWithLenses.second


                saleLenses.forEach { saleLens ->

                    val inventoryUnit =
                        inventoryDao.getById(
                            unitId =
                                saleLens.inventoryUnitId
                        )


                    require(
                        inventoryUnit != null
                    ) {
                        "Selected Inventory Unit ${saleLens.inventoryUnitId} does not exist."
                    }


                    // =========================================
                    // CURRENT STOCK STATUS
                    // =========================================

                    require(
                        inventoryUnit.status
                            .trim()
                            .equals(
                                other = "IN_STOCK",
                                ignoreCase = true
                            )
                    ) {
                        "Serial Number ${inventoryUnit.serialNumber} is no longer available in stock. Current status: ${inventoryUnit.status}."
                    }


                    // =========================================
                    // PRODUCT SAFETY
                    // =========================================

                    require(
                        inventoryUnit.productId ==
                                saleItem.productId
                    ) {
                        "Serial Number ${inventoryUnit.serialNumber} does not belong to Product ${saleItem.productName.trim()}."
                    }


                    // =========================================
                    // SERIAL SNAPSHOT SAFETY
                    // =========================================
                    //
                    // SaleLens serial may come from UI selection,
                    // but Inventory remains authoritative.
                    // =========================================

                    val requestedSerial =
                        saleLens
                            .serialNumber
                            .trim()


                    if (requestedSerial.isNotBlank()) {

                        require(
                            inventoryUnit
                                .serialNumber
                                .trim()
                                .equals(
                                    other =
                                        requestedSerial,

                                    ignoreCase =
                                        true
                                )
                        ) {
                            "Selected Serial Number does not match its Inventory Unit."
                        }
                    }


                    // =========================================
                    // POWER SAFETY
                    // =========================================
                    //
                    // Enforce power only when the Sales Item
                    // itself carries a power value.
                    // =========================================

                    val itemPower =
                        saleItem
                            .power
                            .trim()


                    if (itemPower.isNotBlank()) {

                        require(
                            inventoryUnit
                                .power
                                .trim()
                                .equals(
                                    other =
                                        itemPower,

                                    ignoreCase =
                                        true
                                )
                        ) {
                            "Serial Number ${inventoryUnit.serialNumber} belongs to Power ${inventoryUnit.power}, not $itemPower."
                        }
                    }
                }
            }


            // =================================================
            // STEP 5
            // SAVE SALES DOCUMENT
            // =================================================

            val saleId =
                salesDao.saveCompleteSaleDocument(
                    sale =
                        sale.copy(
                            id = 0L,

                            customerName =
                                sale.customerName.trim(),

                            invoiceNumber =
                                sale.invoiceNumber.trim(),

                            normalizedInvoiceNumber =
                                sale.invoiceNumber
                                    .trim()
                                    .uppercase(),

                            invoiceDate =
                                sale.invoiceDate.trim(),

                            remarks =
                                sale.remarks.trim(),

                            status =
                                "POSTED",

                            cancelledAt =
                                null,

                            cancellationReason =
                                ""
                        ),

                    itemsWithLenses =
                        itemsWithLenses.map {
                                itemWithLenses ->

                            val item =
                                itemWithLenses.first

                            val lenses =
                                itemWithLenses.second


                            item.copy(
                                id = 0L,
                                saleId = 0L,
                                productName =
                                    item.productName.trim(),
                                power =
                                    item.power.trim(),
                                batchNumber =
                                    item.batchNumber.trim(),
                                lotNumber =
                                    item.lotNumber.trim()
                            ) to
                                    lenses.map { lens ->

                                        lens.copy(
                                            id = 0L,
                                            saleItemId = 0L,
                                            serialNumber =
                                                lens.serialNumber.trim(),
                                            power =
                                                lens.power.trim(),
                                            batchNumber =
                                                lens.batchNumber.trim(),
                                            expiryDate =
                                                lens.expiryDate.trim()
                                        )
                                    }
                        }
                )


            require(
                saleId > 0L
            ) {
                "Sales Invoice could not be saved."
            }


            // =================================================
            // STEP 6
            // MARK PHYSICAL INVENTORY AS SOLD
            // =================================================

            itemsWithLenses.forEach { itemWithLenses ->

                val saleLenses =
                    itemWithLenses.second


                saleLenses.forEach { saleLens ->

                    val inventoryUnit =
                        inventoryDao.getById(
                            unitId =
                                saleLens.inventoryUnitId
                        )


                    require(
                        inventoryUnit != null
                    ) {
                        "Inventory Unit ${saleLens.inventoryUnitId} could not be found during Sales posting."
                    }


                    // =========================================
                    // RECHECK BEFORE MUTATION
                    // =========================================

                    require(
                        inventoryUnit.status
                            .trim()
                            .equals(
                                other = "IN_STOCK",
                                ignoreCase = true
                            )
                    ) {
                        "Serial Number ${inventoryUnit.serialNumber} is not available for Sale."
                    }


                    inventoryDao.updateStatus(
                        unitId =
                            inventoryUnit.id,

                        newStatus =
                            "SOLD"
                    )


                    // =========================================
                    // PERMANENT SOLD MOVEMENT
                    // =========================================

                    stockMovementDao.insertMovement(

                        StockMovementEntity(

                            inventoryUnitId =
                                inventoryUnit.id,

                            serialNumber =
                                inventoryUnit
                                    .serialNumber
                                    .trim(),

                            movementType =
                                "SOLD",

                            fromStatus =
                                "IN_STOCK",

                            toStatus =
                                "SOLD",

                            partyName =
                                sale.customerName
                                    .trim(),

                            referenceNumber =
                                sale.invoiceNumber
                                    .trim(),

                            movementDate =
                                sale.invoiceDate
                                    .trim(),

                            remarks =
                                "Stock sold through Sales Invoice ${sale.invoiceNumber.trim()}"
                        )
                    )
                }
            }


            // =================================================
            // STEP 7
            // COMPLETE
            // =================================================

            saleId
        }
    }


    // =========================================================
    // SALES REGISTER
    // =========================================================

    fun getAllSales():
            Flow<List<SaleEntity>> =
        salesDao.getAllSales()


    // =========================================================
    // SALES REGISTER - FINANCIAL YEAR
    // =========================================================

    fun getSalesByFinancialYear(
        financialYearStart: Int
    ): Flow<List<SaleEntity>> =
        salesDao.getSalesByFinancialYear(
            financialYearStart =
                financialYearStart
        )


    // =========================================================
    // SALE BY ID
    // =========================================================

    suspend fun getSaleById(
        saleId: Long
    ): SaleEntity? =
        salesDao.getSaleById(
            saleId =
                saleId
        )


    // =========================================================
    // SALE ITEMS
    // =========================================================

    fun getSaleItems(
        saleId: Long
    ): Flow<List<SaleItemEntity>> =
        salesDao.getSaleItems(
            saleId =
                saleId
        )


    // =========================================================
    // SALE LENSES
    // =========================================================

    fun getSaleLenses(
        saleItemId: Long
    ): Flow<List<SaleLensEntity>> =
        salesDao.getSaleLenses(
            saleItemId =
                saleItemId
        )


    // =========================================================
    // SEARCH SALES REGISTER
    // =========================================================

    fun searchSales(
        query: String
    ): Flow<List<SaleEntity>> =
        salesDao.searchSales(
            query =
                query.trim()
        )


    // =========================================================
    // SALES BY CUSTOMER / HOSPITAL
    // =========================================================

    fun getSalesByCustomer(
        customerId: Long
    ): Flow<List<SaleEntity>> =
        salesDao.getSalesByCustomer(
            customerId =
                customerId
        )
}