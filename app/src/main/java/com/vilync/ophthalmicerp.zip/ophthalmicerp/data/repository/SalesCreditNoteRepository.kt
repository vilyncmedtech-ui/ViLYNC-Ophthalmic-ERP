package com.vilync.ophthalmicerp.data.repository

import com.vilync.ophthalmicerp.data.dao.SalesCreditNoteDao
import com.vilync.ophthalmicerp.data.entity.SalesCreditNoteEntity
import com.vilync.ophthalmicerp.data.entity.SalesCreditNoteItemEntity
import com.vilync.ophthalmicerp.data.entity.SalesCreditNoteLensEntity
import kotlinx.coroutines.flow.Flow

class SalesCreditNoteRepository(
    private val creditNoteDao: SalesCreditNoteDao
) {

    suspend fun insertCreditNote(
        creditNote: SalesCreditNoteEntity
    ): Long {
        return creditNoteDao.insertCreditNote(creditNote)
    }

    suspend fun insertCreditNoteItems(
        items: List<SalesCreditNoteItemEntity>
    ): List<Long> {
        if (items.isEmpty()) return emptyList()
        return creditNoteDao.insertCreditNoteItems(items)
    }

    suspend fun insertCreditNoteLenses(
        lenses: List<SalesCreditNoteLensEntity>
    ) {
        if (lenses.isEmpty()) return
        creditNoteDao.insertCreditNoteLenses(lenses)
    }

    suspend fun updateCreditNote(
        creditNote: SalesCreditNoteEntity
    ) {
        creditNoteDao.updateCreditNote(creditNote)
    }

    suspend fun getCreditNoteById(
        creditNoteId: Long
    ): SalesCreditNoteEntity? {
        return creditNoteDao.getCreditNoteById(creditNoteId)
    }

    fun getAllCreditNotes(): Flow<List<SalesCreditNoteEntity>> {
        return creditNoteDao.getAllCreditNotes()
    }

    fun getCreditNotesByFinancialYear(
        financialYearStart: Int
    ): Flow<List<SalesCreditNoteEntity>> {
        return creditNoteDao.getCreditNotesByFinancialYear(
            financialYearStart
        )
    }

    fun getCreditNotesForCustomer(
        customerId: Long
    ): Flow<List<SalesCreditNoteEntity>> {
        return creditNoteDao.getCreditNotesForCustomer(customerId)
    }

    suspend fun getItemsByCreditNoteId(
        creditNoteId: Long
    ): List<SalesCreditNoteItemEntity> {
        return creditNoteDao.getItemsByCreditNoteId(creditNoteId)
    }

    suspend fun getLensesByCreditNoteId(
        creditNoteId: Long
    ): List<SalesCreditNoteLensEntity> {
        return creditNoteDao.getLensesByCreditNoteId(creditNoteId)
    }

    suspend fun creditNoteNumberExists(
        normalizedCreditNoteNumber: String,
        financialYearStart: Int
    ): Boolean {
        return creditNoteDao.creditNoteNumberExists(
            normalizedCreditNoteNumber =
                normalizedCreditNoteNumber.trim(),
            financialYearStart =
                financialYearStart
        )
    }

    suspend fun physicalReturnAlreadyExists(
        inventoryUnitId: Long
    ): Boolean {
        return creditNoteDao.physicalReturnAlreadyExists(
            inventoryUnitId
        )
    }
}
