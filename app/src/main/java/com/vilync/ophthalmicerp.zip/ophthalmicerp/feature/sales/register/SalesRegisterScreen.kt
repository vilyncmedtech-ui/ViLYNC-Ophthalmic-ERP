package com.vilync.ophthalmicerp.feature.sales.register

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.NumberFormat
import java.util.Locale

private val Navy = Color(0xFF071B33)
private val Gold = Color(0xFFD4AF37)
private val Page = Color(0xFFF7F9FC)

@Composable
fun SalesRegisterScreen(
    viewModel: SalesRegisterViewModel,
    onBack: () -> Unit,
    onDashboard: () -> Unit
) {
    val state = viewModel.uiState.collectAsState().value
    val context = LocalContext.current
    var exportOpen by remember { mutableStateOf(false) }
    val money = remember { NumberFormat.getCurrencyInstance(Locale("en", "IN")) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            OutlinedButton(onClick = onBack) { Text("← Back") }
            Text(viewModel.registerType.screenTitle, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Navy)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box {
                    Button(onClick = { exportOpen = true }, colors = ButtonDefaults.buttonColors(containerColor = Navy)) {
                        Text("EXPORT ▾")
                    }
                    DropdownMenu(expanded = exportOpen, onDismissRequest = { exportOpen = false }) {
                        DropdownMenuItem(text = { Text("Print") }, onClick = {
                            exportOpen = false
                            SalesRegisterExportSuite.print(context, viewModel.registerType.screenTitle, state.rows)
                                .onFailure { Toast.makeText(context, it.message ?: "Unable to print.", Toast.LENGTH_LONG).show() }
                        })
                        DropdownMenuItem(text = { Text("PDF") }, onClick = {
                            exportOpen = false
                            SalesRegisterExportSuite.exportPdfAndShare(context, viewModel.registerType.screenTitle, state.rows)
                                .onFailure { Toast.makeText(context, it.message ?: "Unable to export PDF.", Toast.LENGTH_LONG).show() }
                        })
                        DropdownMenuItem(text = { Text("Excel") }, onClick = {
                            exportOpen = false
                            SalesRegisterExportSuite.exportExcelAndShare(context, viewModel.registerType.screenTitle, state.rows)
                                .onFailure { Toast.makeText(context, it.message ?: "Unable to export Excel.", Toast.LENGTH_LONG).show() }
                        })
                    }
                }
                OutlinedButton(onClick = onDashboard) { Text("⌂ Dashboard") }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(
                value = state.query,
                onValueChange = viewModel::updateQuery,
                label = { Text("Search document / customer / date / status") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(0.82f)
            )
            OutlinedButton(onClick = viewModel::refresh) { Text("Refresh") }
        }

        val statuses = remember(state.rows) {
            listOf("ALL") + state.rows.map { it.status }.filter { it.isNotBlank() }.distinct().sorted()
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            statuses.forEach { status ->
                FilterChip(
                    selected = state.statusFilter == status,
                    onClick = { viewModel.updateStatusFilter(status) },
                    label = { Text(status.replace('_', ' ')) }
                )
            }
        }

        when {
            state.isLoading -> CircularProgressIndicator()
            state.errorMessage != null -> Text(state.errorMessage!!, color = MaterialTheme.colorScheme.error)
            state.rows.isEmpty() -> Card(
                colors = CardDefaults.cardColors(containerColor = Page),
                border = BorderStroke(1.dp, Gold.copy(alpha = .45f))
            ) { Text("No records found.", Modifier.padding(20.dp), color = Navy) }
            else -> state.rows.forEach { row ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color(0xFFDDE3EC))
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.fillMaxWidth(0.72f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(row.documentNumber, fontWeight = FontWeight.Bold, color = Navy)
                            Text("${row.documentDate}  •  ${row.customerName}")
                            if (row.secondaryInfo.isNotBlank()) Text(row.secondaryInfo, style = MaterialTheme.typography.bodySmall)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(row.status.replace('_', ' '), fontWeight = FontWeight.SemiBold, color = Navy)
                            row.amount?.let { Text(money.format(it), fontWeight = FontWeight.Bold) }
                        }
                    }
                }
            }
        }
    }
}
